﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pr_1_7_8
{
    class Group
    {
        private Student[] students;
        private int number_of_nechay;
        public Group()
        {
            students = new Student[0];
        }
        public Group(Student[] list)
        {
            students = list;
            NambersNechay();
        }
        private void NambersNechay()
        {
            number_of_nechay = 0;
            foreach(Student x in students)
            {
                if(x.lastname == "Нечай")
                {
                    ++number_of_nechay;
                }
            }
        }
        public Student this[string name]
        {
            get
            {
                foreach(Student x in students)
                {
                    if(x.firstname == name)
                    {
                        return x;
                    }
                }
                return new Student();
            }
        }
        public int Nechay
        {
            get
            {
                return number_of_nechay;
            }
        }
    }
}
