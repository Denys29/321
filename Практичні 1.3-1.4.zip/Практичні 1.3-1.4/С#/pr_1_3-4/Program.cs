﻿using System;

namespace pr_1_3_4
{
    class StudySubject
    {
        private double hours;
        public StudySubject()
        {
            hours = 0;
        }
        public StudySubject(double hours)
        {
            this.hours = hours;
        }
        public void SetHours(double newHours)
        {
            hours = newHours;
        }
        public double GetHours()
        {
            return hours;
        }
        public void Copy(StudySubject x)
        {
            hours = x.GetHours();
        }
    }
    class Program
    {
        static void Show(StudySubject[] mas)
        {
            foreach(StudySubject x in mas)
            {
                if (x != null)
                {
                    Console.Write(x.GetHours() + " ");
                }
            }
            Console.WriteLine();
        }
        static void Swap(StudySubject x, StudySubject y)
        {
            StudySubject temp = new StudySubject();
            temp.Copy(x);
            x.Copy(y);
            y.Copy(temp);
        }
        static double SumHours(StudySubject[] mas)
        {
            double result = 0;
            foreach(StudySubject x in mas)
            {
                if (x != null)
                {
                    result += x.GetHours();
                }
            }
            return result;
        }
        static void Main(string[] args)
        {
            StudySubject[] mas_discipline = new StudySubject[30];
            for(int i = 0; i < 30; ++i)
            {
                if (i < 14)
                {
                    //mas_discipline[i] = new Discipline(Convert.ToDouble(Console.ReadLine()));
                    mas_discipline[i] = new StudySubject(i + 1);
                }
                else
                {
                    mas_discipline[i] = new StudySubject();
                }
            }
            Show(mas_discipline);

            for(int i = 0; i < 30; i += 2)
            {
                Swap(mas_discipline[i], mas_discipline[i + 1]);
            }
            Show(mas_discipline);

            Console.WriteLine("Sum Hours -> " + SumHours(mas_discipline));
        }
    }
}
