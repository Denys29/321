﻿using System;

namespace pr_1_7_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Student[] list = new Student[]
            {
                new Student("Тарас", "Козодой", "Романович"),
                new Student("Iгор", "Нечай", "Олександрович"),
                new Student("Дмитро", "Мельник", "Сергiйович"),
                new Student("Олексiй", "Нечай", "Петрович"),
                new Student("Лариса", "Нечай", "Iгорiвна"),
                new Student("Свiтлана", "Дуляницька", "Романiвна"),
                new Student("Алiна", "Мiсько", "Арьомiвна"),
            };
            Group group = new Group(list);
            Console.WriteLine(group["Лариса"]);
            Console.WriteLine($"Кiлькiсть Нечайiв -> {group.Nechay}");
        }
    }
}
