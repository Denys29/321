﻿#include <iostream>
#include "Car.h"
using namespace std;

void show(Car mas[30]) {
    for (int i = 0; i < 30; ++i) {
        cout << mas[i].Get_Cap() << " ";
    }
    cout << endl;
}

void swap(Car &car1, Car &car2) {
    Car temp = car1;
    car1 = car2;
    car2 = temp;
}

int find_number_cap(Car mas[30], double capacity) {
    int result = 0;
    for (int i = 0; i < 30; ++i) {
        if (mas[i].Get_Cap() >= capacity) {
            ++result;
        }
    }
    return result;
}

int main()
{
    Car mas_car[30];
    for (int i = 0; i < 14; ++i) {
        double capacity;
        //cin >> capacity;
        capacity = (i + 1) % 5;
        mas_car[i].Set_Cap(capacity);
    }
    show(mas_car);
    
    for (int i = 0; i < 7; ++i) {
        swap(mas_car[i], mas_car[i + 7]);
    }
    show(mas_car);

    double capacity = 2.0;
    cout << "Cars with an engine capacity greater or equal to "
        << capacity << " -> " << find_number_cap(mas_car, capacity) << endl;

}