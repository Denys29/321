﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pr_1_7_8
{
    class Student
    {
        public string firstname;
        public string lastname;
        public string surname;
        public Student() : this("Default", "Default", "Default") { }
        public Student(string fn, string ln, string sn)
        {
            firstname = fn;
            lastname = ln;
            surname = sn;
        }
        public override string ToString()
        {
            return $"{firstname} {lastname} {surname}";
        }
    }
}
