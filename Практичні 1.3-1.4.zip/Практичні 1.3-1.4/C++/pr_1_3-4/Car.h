class Car {
private:
	double engine_capacity;
public:
	Car();
	Car(double _engine_capacity);
	void Set_Cap(double _engine_capacity);
	double Get_Cap();
};

Car::Car() {
	engine_capacity = 0.0;
}

Car::Car(double _engine_capacity) {
	engine_capacity = _engine_capacity;
}

void Car::Set_Cap(double _engine_capacity){
	engine_capacity = _engine_capacity;
}

double Car::Get_Cap() {
	return engine_capacity;
}